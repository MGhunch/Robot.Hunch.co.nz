"""Engine smoke: facts, clauses and the API, no model key needed.
Run: python3 test_engine.py  (after test_reader.py)"""
import os
os.environ.setdefault("ROBOT_WORDS", "taniwha:Michael")
import containers as C, engine as E
from app import app

c = C.container("prize_draw")
form = {"prize_type": "movie", "prize_name": "Practical Magic 2", "winners": "5",
        "opens": "2026-08-24", "closes": "2026-09-06"}
f = E.build_facts(c, form)
assert f["drawn_long"] == "Monday 7 September 2026" and f["plural"] and f["winners_word"] == "five"
terms = E.render_terms(c, f)
assert terms.startswith("• All One New Zealand customers") and "One (1) double pass to see Practical Magic 2" in terms
assert "Winners must comply" in terms and "The winners will be contacted" in terms
assert [m["id"] for m in E.clause_menu(c, f)][:4] == ["eligibility", "entry", "winners", "prize_line"]
for bad, msg in [(dict(form, closes="2026-08-01"), "before"), (dict(form, prize_type="gig"), "needs"),
                 (dict(form, prize_type="Spa"), "don't know"), (dict(form, winners="0"), "at least")]:
    try:
        E.build_facts(c, bad); raise AssertionError(bad)
    except E.TermsError as e:
        assert msg in str(e), (msg, e)
assert E.check_copy(c, "Win 5 passes in September", f)
assert not E.check_copy(c, "Win {winners_word} passes {closes_day}", f, "subject")
assert E.render_copy(c, "by {closes_day}", f) == "by Sunday"

ou = C.container("one_update")
f2 = E.build_facts(ou, {"story": [
    {"story_type": "prize", "story_subject": "Phone Dollars", "story_legals": ["draw", "one_wallet"]},
    {"story_type": "news", "story_subject": "Satellite", "story_legals": ["satellite"]},
    {"story_type": "news", "story_subject": "2G"}]})
assert f2["story"][0]["story_legals"] == ["draw", "one_wallet"] and f2["story"][2]["story_legals"] == []
from copy_stage import _brief, _shape
b = _brief(ou, f2, {}, "dump")
assert "STORY 1: Type: prize · What it's about: Phone Dollars · Legals: draw, One Wallet redemption" in b and "story_legals" not in b
assert len(_shape(ou, f2)[0]["cards"]) == 3
try:
    E.build_facts(ou, {"story": [{"story_type": "prize", "story_subject": "x"}]}); raise AssertionError
except E.TermsError as e:
    assert "3 to 5" in str(e)
assert E.check_copy(ou, "x" * 170, f2, "card-body")
print("engine ok")

t = app.test_client()
assert t.get("/api/containers").status_code == 401
t.post("/api/auth/word", json={"word": "unicorn", "name": "Suze"})
assert [x["id"] for x in t.get("/api/containers").get_json()["tiles"]] == ["prize_draw"]
assert t.get("/api/container/one_update").status_code == 404
t.post("/api/auth/word", json={"word": "taniwha"})
d = t.get("/api/containers").get_json()
assert d["hunch"] and {x["id"] for x in d["tiles"]} == {"one_update", "prize_draw"}
d = t.get("/api/container/one_update").get_json()
assert d["quiz"]["bounce"][0]["need"] == "point" and d["quiz"]["point"] and d["checklist"]["groups"][0]["repeat"] == {"per": "story", "min": 3, "max": 5, "where": None}
t0 = d["checklist"]["topics"][0]
assert {k: t0[k] for k in ("id", "label", "default", "when")} == {"id": "draw", "label": "Prize draw clause", "default": True, "when": "prize"}
assert "competition" in t0["text"]          # topics carry their words for the peek
assert d["checklist"]["legals"]["fixedTitle"] == "Standard footer" if d.get("_cid") == "one_update" else True
assert "/brands/one_nz/assets/" in d["html"] and d["ghost"][0] == "precopy"
r = t.post("/api/terms", json={"container": "prize_draw", "form": form}).get_json()
assert len(r["menu"]) == 15 and r["footer"].startswith("For any queries")
r = t.post("/api/parcel", json={"container": "prize_draw", "form": form,
                                "copy": {"subject": "Win {winners_word} by {closes_day}", "headline": "h", "body": "b"}}).get_json()
assert r["copy"]["subject"] == "Win five by Sunday" and r["slug"] == "practical-magic-2" and r["clause_count"] == 12
# the bounce with no key: the three needs in order, then a close. It never
# claims the robot spoke (live:false) and it never asks a fourth time.
f0 = t.post("/api/feeder", json={"container": "one_update", "turns": []}).get_json()
assert f0["need"] == "point" and f0["ask"] == "What's this all about?" and not f0["live"] and not f0["done"]
f1 = t.post("/api/feeder", json={"container": "one_update",
                                 "turns": [{"ask": "a", "answer": "four cards"}]}).get_json()
assert f1["need"] == "insight" and f1["ask"] == "What's the one thing people will love?"
f3 = t.post("/api/feeder", json={"container": "one_update", "turns": [
    {"ask": "a", "answer": "four cards"}, {"ask": "b", "answer": "the toilet one"},
    {"ask": "c", "answer": "small stories, big year"}]}).get_json()
assert f3["done"] and f3["ask"] == "" and f3["brief"]["angle"] == "small stories, big year"
assert f3["brief"]["point"] == "four cards" and f3["brief"]["insight"] == "the toilet one"
assert t.post("/api/copy", json={"container": "nope"}).status_code == 404
assert t.get("/").status_code == 200
print("api ok")
