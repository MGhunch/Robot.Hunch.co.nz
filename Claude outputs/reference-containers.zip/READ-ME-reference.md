# REFERENCE CONTAINERS — for the SET UPs project
*4 September 2026, out of the engine repo at v042. These two folders are
what the reader accepts today, not what a doc says it should. Both read
clean: `validate()` returns zero problems on each.*

Drop this whole thing into the SET UPs project as reference. Then a
container gets written against something the reader has already said yes
to, rather than against prose.

## containers/one_update/  — the repeating one
Three files: config.md, spec.md, container.html.

Shows:
- **the Bounce it table** keyed by need name (`point` / `insight` / `angle`)
- **the repeating-group heading grammar** — `### THE LINEUP (repeats per
  story, 3-5)`, the form the reader keys off
- **`topics from LEGALS below`** — the square-checkbox rows hung under a
  repeating card
- **`### Per card`** clauses that fire once per repeating item
- 17 modules against 22 data-module tags in the html, i.e. what structural
  wrappers look like when they pass

## containers/prize_draw/  — the conditional one
Three files, same three names.

Shows:
- **the `when` column** — `prize_type in gig, sport`, a row that only
  appears sometimes
- **the `after` column** — `closes` after `opens`, the order rule
- **the `derive` column** — `next working day after closes`, and the prize
  type's ticket words
- **`### By prize type`** — a block per type with `prize_line:`, `counts:`,
  `counts_one:`, `sentence:`, `needs:` and an extras table with `after`
- **how LEGALS placeholders resolve** — `### Facts the clauses fill from`
  declaring the derived forms (`{winners_word}`, `{closes_long}`,
  `{event_short}`) that aren't plain NEEDS ids
- **`@brand`** clause pulls against brands/one_nz/brandlegals.md

## The brand they both point at
`brands/one_nz/` is in the SET UPs project already. Both of these name
`brand: one_nz`, so they only read clean beside it.

## What changed in the reader on 4 Sep (v042) that SCHEMA-v3 doesn't say yet
- Two-font brands are read: `**Font - headlines:**` / `**Font - body:**`.
  `skin.fonts` is a list of {role, text}; `skin.font` stays as the first.
  The "lead with a plain **Font:** line" workaround can go.
- `**Mark:**` is carried beside `Logo`.
- A brandlook.md with no font line at all now bounces.
- The compiled cache is stamped with the parser's version, so a parser
  change rebuilds every cache. The "touch config.md" note can go.

*Honest.*
